<?php

namespace App\Http\Controllers;

use App\Employees;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TestingController extends Controller
{
    public function testing(){
        $nik    = DB::table('hr_employees')->select("emp_num")->where('name', 'SUGIANTO')->get();
        $pinUser= DB::table('users')->select('pin')->where('emp_num',$nik[0]->emp_num)->get();

        dd($pinUser[0]->pin);
    }
}
